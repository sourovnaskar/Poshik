require("dotenv").config();

const bcrypt = require("bcryptjs");

const connectDB = require("./app/config/db");

const User = require("./app/models/userModel");

const seed = async () => {
  try {
    await connectDB();

    const existAdmin = await User.findOne({ role: "Admin" });

    if (!existAdmin) {
      const password = await bcrypt.hash("Admin@123", 10);

      await User.create({
        name: "Admin",
        email: "admin@petapp.com",
        password: password,
        role: "Admin",
        kycStatus: "Not Applicable",
        isEmailVerify: true,
      });

      console.log("Admin Created Successfully");
    } else {
      console.log("Admin Already Exists");
    }

    process.exit(0);
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
};

seed();
